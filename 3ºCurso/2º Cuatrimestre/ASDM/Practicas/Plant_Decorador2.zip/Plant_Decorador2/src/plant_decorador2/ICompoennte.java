/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package plant_decorador2;

/**
 *
 * @author carlo
 */
public interface ICompoennte {
    public String getDescripcion();
    public float getPrecio();
}
